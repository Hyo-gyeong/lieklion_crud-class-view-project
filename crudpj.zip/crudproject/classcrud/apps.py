from django.apps import AppConfig


class ClasscrudConfig(AppConfig):
    name = 'classcrud'
